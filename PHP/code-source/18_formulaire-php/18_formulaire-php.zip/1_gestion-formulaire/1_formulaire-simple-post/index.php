<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome.php" method="post">
Nom: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
<input type="submit" value="Envoyer">
</form>

</body>
</html>